export interface Product {
  id: number;
  name: string;
  probability: number;
  description: string;
}

export const products = [
  {
    id: 1,
    name: 'Money-Line',
    probability: 0.2,
    description: 'Which player will win the game'
  },
  {
    id: 2,
    name: 'Exact_Number_of_Games',
    probability: 0.3,
    description: 'How many sets will be played during the game'
  },
  {
    id: 3,
    name: 'Total-Point',
    probability: 0.4,
    description: 'Sum of two player individual points together'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/