# SSW695_Ping-Pong_King
Demo:
![image]( https://github.com/konglingwengit/SSW695_Ping-Pong_King/blob/main/demo.jpg)
