import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiServices } from './services/ApiServices';

interface DumpDataObject {
  name: string,
  code: string
}

interface Players {
  player1: string,
  player2: string
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ping-pong-kong';
  validForm:boolean|null = true;
  data:Array<DumpDataObject> = [];
  players: Players;

  constructor (
    private apiService: ApiServices
  ) {
    this.players = {
      player1: '',
      player2: ''
    }
  }


  handlePredict(f: NgForm) {
    this.validForm = f.valid;
    if (f.valid) {
      const {player1, player2} = f.value;
      this.players = {player1, player2};
      this.apiService.callDumpJson().subscribe((response:any) => {
        this.data = response;
      })
    }
  }

}
